/**
 * @fileType api-endpoint
 * @domain kody
 * @pattern github-webhook
 *
 * POST /api/webhooks/github
 *
 * GitHub webhook receiver. When GITHUB_WEBHOOK_SECRET or KODY_WEBHOOK_SECRET
 * is configured, verifies X-Hub-Signature-256 before accepting a delivery.
 * Deployments without a secret keep the legacy GitHub CIDR check.
 *
 * On accepted delivery, invalidates the in-memory cache for the affected
 * resource so the next read picks up the change without waiting for TTL.
 *
 * This is the foundation of the push-based architecture that replaces
 * polling. See CLAUDE.md > "GitHub API rate-limit rules".
 *
 * Subscribed events (configured at hook registration):
 *   issues, issue_comment, pull_request, pull_request_review,
 *   workflow_run, workflow_job, check_run, push, release
 *
 * Idempotency: GitHub may deliver the same event more than once. We dedupe
 * by X-GitHub-Delivery via an in-memory LRU. Cross-instance duplicate
 * delivery is harmless — invalidation is idempotent.
 */

import { NextRequest, NextResponse } from "next/server";
import { createHmac, timingSafeEqual } from "node:crypto";
import {
  invalidateIssueCache,
  invalidatePRCache,
  invalidateBranchCache,
  invalidateWorkflowCache,
  invalidatePRBehindCache,
  invalidateDiscussionCache,
} from "@dashboard/lib/github-client";
import { getClientIp, isFromGitHub } from "@dashboard/lib/webhooks/github-ip";
import { logger } from "@dashboard/lib/logger";
import { dispatchNotifications } from "@dashboard/lib/notifications-dispatch";
import { dispatchMentionPushes } from "@dashboard/lib/push/mention-dispatch";
import { dispatchAgentMentions } from "@dashboard/lib/push/agent-mention-dispatch";
import { dispatchCapabilityFailures } from "@dashboard/lib/push/capability-failure-dispatch";
import { dispatchReportPushes } from "@dashboard/lib/push/report-dispatch";
import { applyVerdictFromComment } from "@dashboard/lib/ui-verify/apply-label";
import {
  handlePrMerged,
  handleReleasePublished,
} from "@dashboard/lib/changelog/handlers";
import {
  handleDefaultBranchPush as handlePreviewDefaultBranchPush,
  handlePrClosed as handlePreviewPrClosed,
  handlePrOpenedOrSynced as handlePreviewPrOpenedOrSynced,
  handleTrackedBranchPush as handlePreviewTrackedBranchPush,
} from "@dashboard/lib/previews/webhook";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// ============ Delivery auth ============

function getWebhookSecret(): string | null {
  return (
    process.env.GITHUB_WEBHOOK_SECRET?.trim() ||
    process.env.KODY_WEBHOOK_SECRET?.trim() ||
    null
  );
}

function verifyWebhookSignature(
  rawBody: string,
  signatureHeader: string | null,
  secret: string,
): boolean {
  if (!signatureHeader?.startsWith("sha256=")) return false;
  const suppliedHex = signatureHeader.slice("sha256=".length);
  if (!/^[0-9a-f]{64}$/i.test(suppliedHex)) return false;

  const expectedHex = createHmac("sha256", secret)
    .update(rawBody, "utf8")
    .digest("hex");
  const supplied = Buffer.from(suppliedHex, "hex");
  const expected = Buffer.from(expectedHex, "hex");
  return (
    supplied.length === expected.length && timingSafeEqual(supplied, expected)
  );
}

// ============ Delivery dedupe (per-instance) ============

const SEEN_DELIVERIES_MAX = 512;
const seenDeliveries = new Set<string>();
const seenOrder: string[] = [];

function rememberDelivery(id: string): boolean {
  if (seenDeliveries.has(id)) return true;
  seenDeliveries.add(id);
  seenOrder.push(id);
  if (seenOrder.length > SEEN_DELIVERIES_MAX) {
    const evicted = seenOrder.shift();
    if (evicted) seenDeliveries.delete(evicted);
  }
  return false;
}

// ============ Event dispatch ============

interface IssuesPayload {
  issue?: { number?: number };
}
interface IssueCommentPayload {
  action?: string;
  issue?: { number?: number; pull_request?: unknown };
  comment?: { body?: string; user?: { login?: string } };
}
interface PullRequestPayload {
  action?: string;
  /** Previous head SHA — present on `synchronize` actions (i.e. push to PR
   *  branch). Used to ask GitHub which files changed since the last sync,
   *  so engine-only pushes can skip the Fly build entirely. */
  before?: string;
  pull_request?: {
    number?: number;
    merged?: boolean;
    head?: { sha?: string; ref?: string };
  };
  repository?: { full_name?: string };
}

interface ReleasePayload {
  action?: string;
  release?: { tag_name?: string };
}

interface PushPayload {
  ref?: string;
  after?: string;
  head_commit?: {
    id?: string;
    added?: string[];
    modified?: string[];
    removed?: string[];
  };
  repository?: {
    full_name?: string;
    default_branch?: string;
  };
}
/**
 * Best-effort side effect: never block the webhook response on it, and never
 * let a rejection crash the receiver. Errors are logged inside each handler.
 */
function logSideEffectError(err: unknown, label: string): void {
  logger.error(
    {
      event: "webhook_side_effect_crashed",
      label,
      error: err instanceof Error ? err.message : String(err),
    },
    `${label} handler threw — should have been caught internally`,
  );
}

function fireAndForget(promise: Promise<unknown>, label: string): void {
  promise.catch((err: unknown) => logSideEffectError(err, label));
}

function mustFinish(promise: Promise<unknown>, label: string): Promise<void> {
  return promise.then(
    () => undefined,
    (err: unknown) => {
      logSideEffectError(err, label);
    },
  );
}

interface DispatchResult {
  handled: boolean;
  detail: string;
  /** Work that must finish before ACKing the webhook in serverless. */
  requiredEffects?: Promise<void>[];
}

function dispatch(event: string, payload: unknown): DispatchResult {
  switch (event) {
    case "ping":
      return { handled: true, detail: "ping" };

    case "issues": {
      const p = payload as IssuesPayload;
      const num = p?.issue?.number;
      invalidateIssueCache(typeof num === "number" ? num : undefined);
      return { handled: true, detail: `issue#${num ?? "?"}` };
    }

    case "issue_comment": {
      const p = payload as IssueCommentPayload;
      const num = p?.issue?.number;
      invalidateIssueCache(typeof num === "number" ? num : undefined);

      // ui-verify side-effect: if this is a new comment on a PR (issues
      // with a `pull_request` field) and the body carries a ui-review
      // verdict marker, apply the verdict label. Idempotent — addLabels
      // is a no-op when the label is already present.
      const isPrComment = !!p?.issue?.pull_request;
      const isCreated = p?.action === "created";
      const body = p?.comment?.body ?? "";
      if (
        isPrComment &&
        isCreated &&
        typeof num === "number" &&
        body.includes("Verdict")
      ) {
        fireAndForget(
          applyVerdictFromComment(num, body),
          `applyVerdictFromComment#${num}`,
        );
      }

      return { handled: true, detail: `issue#${num ?? "?"}` };
    }

    case "pull_request":
    case "pull_request_review":
    case "pull_request_review_comment": {
      const p = payload as PullRequestPayload;
      const requiredEffects: Promise<void>[] = [];
      invalidatePRCache();
      invalidatePRBehindCache();
      // PRs are also exposed as issues in the GitHub API; clear that too.
      invalidateIssueCache(p?.pull_request?.number);
      // On merge, append a bullet to CHANGELOG.md under `## [Unreleased]`.
      // Idempotent on PR number; fire-and-forget so a slow GitHub write
      // never blocks the webhook ACK.
      if (
        event === "pull_request" &&
        p?.action === "closed" &&
        p?.pull_request?.merged
      ) {
        fireAndForget(
          handlePrMerged(payload as Record<string, unknown>),
          `changelog.append#${p.pull_request.number ?? "?"}`,
        );
      }
      // Tear down per-PR preview when the PR closes (merged OR not).
      // No-op when the target repo isn't opted into previews (no
      // FLY_API_TOKEN in vault) — handler resolves the config itself.
      if (
        event === "pull_request" &&
        p?.action === "closed" &&
        typeof p?.pull_request?.number === "number" &&
        p?.repository?.full_name
      ) {
        requiredEffects.push(
          mustFinish(
            handlePreviewPrClosed({
              repoFullName: p.repository.full_name,
              prNumber: p.pull_request.number,
            }),
            `previews.destroy#${p.pull_request.number}`,
          ),
        );
      }
      // Build + boot a preview on PR open, sync (push to branch), or
      // reopen. Same opt-in via vault FLY_API_TOKEN.
      if (
        event === "pull_request" &&
        (p?.action === "opened" ||
          p?.action === "synchronize" ||
          p?.action === "reopened") &&
        typeof p?.pull_request?.number === "number" &&
        p?.pull_request?.head?.sha &&
        p?.repository?.full_name
      ) {
        requiredEffects.push(
          mustFinish(
            handlePreviewPrOpenedOrSynced({
              repoFullName: p.repository.full_name,
              prNumber: p.pull_request.number,
              ref: p.pull_request.head.sha,
              // Only set on `synchronize` (push to PR branch). When
              // present, the handler skips the build if the diff
              // before..head is engine-only (.kody/** + CHANGELOG).
              beforeSha:
                p.action === "synchronize" && p.before ? p.before : undefined,
            }),
            `previews.create#${p.pull_request.number}`,
          ),
        );
      }
      return {
        handled: true,
        detail: `pr#${p?.pull_request?.number ?? "?"}`,
        requiredEffects,
      };
    }

    case "release": {
      const p = payload as ReleasePayload;
      if (p?.action === "published") {
        fireAndForget(
          handleReleasePublished(payload as Record<string, unknown>),
          `changelog.promote#${p.release?.tag_name ?? "?"}`,
        );
      }
      return {
        handled: true,
        detail: `release:${p?.release?.tag_name ?? "?"}`,
      };
    }

    case "check_run": {
      invalidateWorkflowCache();

      // ui-verify auto-dispatch is DISABLED. Previously, every successful
      // Vercel preview check auto-posted `@kody ui-review`. With auto-sync
      // re-pushing ~30 open PRs every cycle, each rebuild produced a fresh
      // preview-ready check, so this re-fired endlessly (984 comments
      // observed) and jammed the engine's Actions queue. The per-PR guard
      // label didn't hold because the SHA changes on every sync.
      //
      // UI review is now opt-in only: the explicit "Request UI review"
      // button in PreviewActions still posts `@kody ui-review` on demand.
      // Re-enabling auto-dispatch requires SHA/preview-URL-keyed dedup so
      // a rebuild of the same PR can't re-trigger it.

      return { handled: true, detail: event };
    }

    case "workflow_run":
    case "workflow_job":
    case "check_suite":
      invalidateWorkflowCache();
      return { handled: true, detail: event };

    case "push": {
      invalidateBranchCache();
      // A push to base branch makes every open PR potentially behind; clear
      // the per-PR behind-by cache so the Preview Sync button updates.
      invalidatePRBehindCache();
      // Default-branch push → refresh the per-repo GHCR base image so
      // future PR builds inherit fresh deps + build cache. Skipped at
      // the handler level for engine-only pushes (.kody/** + CHANGELOG).
      const p = payload as PushPayload;
      const defaultBranch = p?.repository?.default_branch;
      const ref = p?.ref;
      const repoFullName = p?.repository?.full_name;
      const head = p?.head_commit;
      const sha = head?.id ?? p?.after;
      const branch = ref?.startsWith("refs/heads/")
        ? ref.slice("refs/heads/".length)
        : null;
      const isDeletedRef = Boolean(sha && /^0+$/.test(sha));
      const changedPaths = [
        ...(head?.added ?? []),
        ...(head?.modified ?? []),
        ...(head?.removed ?? []),
      ];
      const requiredEffects: Promise<void>[] = [];
      if (repoFullName && branch && sha && !isDeletedRef) {
        requiredEffects.push(
          mustFinish(
            handlePreviewTrackedBranchPush({
              repoFullName,
              branch,
              ref: sha,
              changedPaths,
            }),
            `previews.branch#${repoFullName}@${branch}`,
          ),
        );
      }
      if (
        defaultBranch &&
        ref === `refs/heads/${defaultBranch}` &&
        repoFullName &&
        sha &&
        !isDeletedRef
      ) {
        requiredEffects.push(
          mustFinish(
            handlePreviewDefaultBranchPush({
              repoFullName,
              ref: sha,
              changedPaths,
            }),
            `previews.base-rebuild#${repoFullName}@${sha.slice(0, 7)}`,
          ),
        );
      }
      return { handled: true, detail: event, requiredEffects };
    }

    case "create":
    case "delete":
      invalidateBranchCache();
      invalidatePRBehindCache();
      return { handled: true, detail: event };

    case "discussion":
    case "discussion_comment":
      // New comment on a goal-backing discussion → wipe both the comment
      // cache and the meta cache (the discussion event payload doesn't carry
      // the discussion number, and the meta is cheap to refetch).
      invalidateDiscussionCache();
      return { handled: true, detail: event };

    case "repository":
      // Repo capabilities (Discussions toggled, categories renamed) may have
      // changed. Drop the cached meta so the next read re-checks GitHub.
      invalidateDiscussionCache();
      return { handled: true, detail: event };

    default:
      return { handled: false, detail: event };
  }
}

// ============ Handler ============

export async function POST(req: NextRequest): Promise<NextResponse> {
  let rawBody: string;
  try {
    rawBody = await req.text();
  } catch {
    return NextResponse.json({ error: "invalid body" }, { status: 400 });
  }

  const secret = getWebhookSecret();
  if (secret) {
    const ok = verifyWebhookSignature(
      rawBody,
      req.headers.get("x-hub-signature-256"),
      secret,
    );
    if (!ok) {
      logger.warn(
        { event: "webhook_bad_signature" },
        "Webhook rejected: invalid GitHub signature",
      );
      return NextResponse.json({ error: "forbidden" }, { status: 403 });
    }
  } else {
    const ip = getClientIp(req.headers);
    const allowed = await isFromGitHub(ip);
    if (!allowed) {
      logger.warn(
        { event: "webhook_unauthorized_ip", ip: ip ?? "(none)" },
        "Webhook rejected: source IP not in GitHub's hook CIDRs",
      );
      return NextResponse.json({ error: "forbidden" }, { status: 403 });
    }
  }

  const eventType = req.headers.get("x-github-event") ?? "";
  const deliveryId = req.headers.get("x-github-delivery") ?? "";

  if (deliveryId && rememberDelivery(deliveryId)) {
    return NextResponse.json({ ok: true, dedup: true }, { status: 200 });
  }

  let payload: unknown;
  try {
    payload = JSON.parse(rawBody);
  } catch {
    return NextResponse.json({ error: "invalid JSON" }, { status: 400 });
  }

  const result = dispatch(eventType, payload);
  logger.info(
    {
      event: "webhook_received",
      type: eventType,
      delivery: deliveryId,
      handled: result.handled,
      detail: result.detail,
    },
    "GitHub webhook processed",
  );

  // Fire-and-forget Slack notifications. Errors are swallowed inside; we
  // never want a failed Slack POST to cause GitHub to retry the delivery.
  if (typeof payload === "object" && payload !== null) {
    const obj = payload as Record<string, unknown>;
    dispatchNotifications(eventType, obj).catch((err: unknown) => {
      logger.error(
        {
          event: "notifications_dispatch_crashed",
          error: err instanceof Error ? err.message : String(err),
        },
        "dispatchNotifications threw — should have been caught internally",
      );
    });
    // Push @mentions to the mentioned users' devices + record the inbox feed.
    // AWAIT it: on Vercel serverless, fire-and-forget work is killed once the
    // response is sent, so the (vault-token + manifest-write) save must finish
    // before we return or the inbox entry is silently lost.
    await dispatchMentionPushes(eventType, obj).catch((err: unknown) => {
      logger.error(
        {
          event: "mention_push_dispatch_crashed",
          error: err instanceof Error ? err.message : String(err),
        },
        "dispatchMentionPushes threw — should have been caught internally",
      );
    });
    // @agent mentions → one-shot agent-ask tick, reply back in-thread.
    // Same GitHub-backed surfaces as mention push (messages, goals, tasks,
    // previews, PR/issue comments, reviews) — one hook covers them all.
    await dispatchAgentMentions(eventType, obj).catch((err: unknown) => {
      logger.error(
        {
          event: "agent_mention_dispatch_crashed",
          error: err instanceof Error ? err.message : String(err),
        },
        "dispatchAgentMentions threw — should have been caught internally",
      );
    });
    // Failed capability run → inbox entry for every operator. Triggered by the
    // engine's activity-log commit to the state repo (a `push` event), so
    // a silent cron failure surfaces without any engine change. Awaited for
    // the same serverless reason as the mention feed write above.
    await dispatchCapabilityFailures(eventType, obj).catch((err: unknown) => {
      logger.error(
        {
          event: "capability_failure_dispatch_crashed",
          error: err instanceof Error ? err.message : String(err),
        },
        "dispatchCapabilityFailures threw — should have been caught internally",
      );
    });
    // New report run committed under <repo>/reports/<slug>/runs/ in the state repo →
    // broadcast browser banner to every subscribed device for the repo, so a
    // report landing feels like an inbox/mention ping. Awaited for the same
    // serverless reason as the entries above.
    await dispatchReportPushes(eventType, obj).catch((err: unknown) => {
      logger.error(
        {
          event: "report_push_dispatch_crashed",
          error: err instanceof Error ? err.message : String(err),
        },
        "dispatchReportPushes threw — should have been caught internally",
      );
    });
  }

  if (result.requiredEffects?.length) {
    await Promise.all(result.requiredEffects);
  }

  return NextResponse.json(
    { ok: true, handled: result.handled },
    { status: 200 },
  );
}
